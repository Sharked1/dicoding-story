package com.dicoding.picodiploma.loginwithanimation.di

import android.content.Context
import com.dicoding.mycamerastarter.data.api.ApiConfig
import com.dicoding.mystoryapp.data.UserRepository
import com.dicoding.picodiploma.loginwithanimation.data.pref.UserPreference
import com.dicoding.picodiploma.loginwithanimation.data.pref.dataStore

object Injection {
    fun provideRepository(context: Context): UserRepository {
        val pref = UserPreference.getInstance(context.dataStore)
        val apiService = ApiConfig.getApiService()
        return UserRepository.getInstance(pref, apiService)
    }
}